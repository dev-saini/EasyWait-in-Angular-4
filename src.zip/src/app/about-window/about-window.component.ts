import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-window',
  templateUrl: './about-window.component.html',
  styleUrls: ['./about-window.component.css']
})
export class AboutWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
